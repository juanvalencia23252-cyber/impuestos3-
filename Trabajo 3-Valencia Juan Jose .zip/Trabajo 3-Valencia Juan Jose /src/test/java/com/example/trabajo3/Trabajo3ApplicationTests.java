package com.example.trabajo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabajo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
